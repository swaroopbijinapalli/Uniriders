How to generate a Firebase service account key (for server-side token verification):

1. Go to Firebase Console -> Project Settings -> Service accounts.
2. Click 'Generate new private key'. This downloads a JSON file.
3. Place that file at server/serviceAccountKey.json (next to app.js).
4. Restart the Node server. The server will then verify Firebase ID tokens for socket connections.

WARNING: Keep this file secret. Do NOT commit it to public repositories.
