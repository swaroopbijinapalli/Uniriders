UniRiders Demo Script — Quick guide for presentation

Goal: Show live tracking with one browser acting as the driver and one as the student/dashboard.

1. Start the server:
   cd server
   npm install
   npm start
   Open http://localhost:3000 in your laptop browser.

2. Open two tabs/windows:
   - Tab A: http://localhost:3000/login.html  (use "Sign in as Demo Driver")
   - Tab B: http://localhost:3000/login.html  (use "Sign in as Demo Student")

3. On Tab A (Demo Driver):
   - Click "Sign in as Demo Driver". A vehicleId like veh-demo-123 will be generated and the demo driver will start sending location updates every 3s.
   - The page status will show current coords.

4. On Tab B (Demo Student):
   - Click "Sign in as Demo Student". When prompted, enter the vehicleId shown on Tab A (e.g., veh-demo-123). If you leave blank it defaults to veh-demo-100.
   - Tab B will join the vehicle room and begin receiving 'vehicle:location' events. The demoLive element will show the latest update.

5. Alternatively, open http://localhost:3000/dashboard.html to see all vehicle locations broadcasted to admin viewers.
   - Dashboard will show markers for vehicles if Leaflet is enabled.

Notes:
- This demo mode works when server/serviceAccountKey.json is NOT added (dev mode).
- For real auth, replace firebaseConfig in public/login.html and add the service account file to server/.
