UniRiders updated package

- server/: Express + Socket.io server (verify Firebase ID tokens if serviceAccountKey.json provided)
- public/: static frontend (index.html, login.html, myrides.html, styles.css, script.js)
- To run: cd server && npm install && node app.js
- Put your Firebase service account JSON at server/serviceAccountKey.json
- Replace firebaseConfig in public/login.html with your project's config
